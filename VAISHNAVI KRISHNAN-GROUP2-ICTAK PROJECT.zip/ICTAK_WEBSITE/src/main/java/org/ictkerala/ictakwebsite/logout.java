package org.ictkerala.ictakwebsite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class logout
{
 WebDriver driver;
 @FindBy(xpath="//h1[text()='ICT Academy of Kerala']")
 WebElement logoutverify;
 @FindBy(xpath="//a[@data-bs-toggle='collapse' and @href='#ProfileNav' and @role='button' and @aria-expanded='false']")
 private WebElement Admin;
 @FindBy(xpath="//*[@id=\"ProfileNav\"]/ul/li/a")
 private WebElement Logout;

	public logout(WebDriver driver)
	{
			this.driver = driver;
			PageFactory.initElements(driver, this);
	}
	
public void logoutfunction()
{
Admin.click();
Logout.click();
}
public String logoutverify()
{
	String ActualText=logoutverify.getText();
	return(ActualText);
}

}
