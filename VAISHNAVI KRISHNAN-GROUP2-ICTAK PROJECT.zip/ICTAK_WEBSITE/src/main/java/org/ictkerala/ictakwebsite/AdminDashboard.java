package org.ictkerala.ictakwebsite;


import static org.testng.AssertJUnit.assertEquals;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AdminDashboard

{

WebDriver driver;
JavascriptExecutor js = (JavascriptExecutor) driver;
@FindBy(xpath="//a[class='btn btn-sm bg-gradient-info mb-0 me-1 mt-2 mt-md-0']")
WebElement LoginButton;
@FindBy(xpath="//h4[text()= 'Dashboard']")
private WebElement Dashboard;
@FindBy(xpath="//h2[@class='fw-bold px-5 headtxt1 ms-4' and text()='ICT LIVE STATUS']")
private WebElement Chart;
@FindBy(xpath="//button[@type='submit' and @name='sds']")
private	WebElement Task;
@FindBy(xpath="//h2[@id='swal2-title' and text()='Empty Submission']")
private WebElement EmptySub;
@FindBy(xpath="//button[@type='button' and text()='OK']")
private	WebElement Ok;
@FindBy(xpath="//a[@class='btn bg-gradient-primary btn-sm mb-0 text-white' and contains(text(), 'New Testimony')]")
private WebElement NewTest;
@FindBy(xpath="//a[@class='fixed-plugin-button text-dark position-fixed px-3 py-2']")
private WebElement Setting1;
@FindBy(xpath="//a[@routerlink=\"/adminpage/testimony\"]")
private WebElement Testimonials;
@FindBy(xpath="//*[@id=\"navbarBlur\"]/div/nav/h4")
private WebElement TestimonyList;
@FindBy(xpath="//*[@id=\"navbarBlur\"]/div/nav/h4")
private WebElement acad;
@FindBy(xpath="//*[@id=\"navbarBlur\"]/div/nav/h4")
private WebElement corp;
@FindBy(xpath="//h4[text()='Partnership Application']")
private WebElement partner;
@FindBy(xpath="//h4[text()='Course Registered Users']")
private WebElement CRU;
@FindBy(xpath="//*[@id='listSearch']")
private WebElement search;
@FindBy(xpath="//h4[text()='Industrial List']")
private WebElement industrypageverify;
@FindBy(xpath="//h4[text()='Knowledge Partner']")
private WebElement knowledgepageverify;
@FindBy(xpath="//h4[text()='Patrons List']")
private WebElement patronpageverify;
@FindBy(xpath="//h4[text()='Events list']")
private WebElement eventsverify;
@FindBy(xpath="//h4[text()='Staff List']")
private WebElement staffspageverify;
@FindBy(xpath="//h4[text()='Admin Users']")
private WebElement adminuserverify;
@FindBy(xpath="//a[@routerlink=\"/adminpage/addcourses\"]")
private WebElement AddCourse;
@FindBy(xpath="//a[@routerlink=\"/adminpage/courses\"]")
private WebElement Courses;
@FindBy(xpath="//p[text()='SoftwareTesting']")
private WebElement searchverify;
@FindBy(xpath="//p[text()='SoftwareTesting']")
private WebElement editverify;
@FindBy(xpath="//i[@class='fas fa-eye text-info'][@title='View the Course']")
private WebElement view;
@FindBy(xpath="//*[@id=\"navbarBlur\"]/div/nav/h4")
private WebElement CoursesList;
@FindBy(xpath="//i[@class='fas fa-edit ms-3 text-warning']")
private WebElement EditCourse;
@FindBy(xpath="//input[@type='text' and @formcontrolname='title' and @required and @name='title' and contains(@class, 'form-control')]")
private WebElement NameField;
@FindBy(xpath="//a[@routerlink=\"/adminpage/courses\"]")
private WebElement Update;
@FindBy(xpath="//p[text()='CERTIFIED SPECIALIST IN SOFTWARE TESTING']")
private WebElement SearchverifyTestimony;

@FindBy(xpath="//input[@name='name']")
private WebElement name;
@FindBy(xpath="//input[@name='org']")
private WebElement organisation;
@FindBy(xpath="//textarea[@formcontrolname='testi']")
private WebElement testi;
@FindBy(xpath="//select[@formcontrolname='title']")
private WebElement CourseSelect;
@FindBy(xpath="//input[@formcontrolname='img' and @type='file']")
private WebElement ChooseFileTestimony;
@FindBy (xpath="//button[@type='submit' and @title= 'Next']")
private WebElement AddTestimonybuttons;
@FindBy(xpath="//h2[text()= 'Successfully Added']")
private WebElement Testimonyaddverify;
@FindBy(xpath="//a[@routerlink=\"/adminpage/registered-users\"]")
private WebElement CourseReg;
@FindBy(xpath="//button[@class='btn bg-gradient-primary btn-sm mb-0']")
private WebElement Download1;
@FindBy(xpath="//a[@routerlink=\"/adminpage/academic\"]")
private WebElement AcademicMembership;
@FindBy(xpath="//button[@class='btn bg-gradient-primary btn-sm mb-0']")
private WebElement Download2;
@FindBy(xpath="//a[@routerlink=\"/adminpage/corporate\"]")
private WebElement CorporateMembership; 
@FindBy(xpath="//button[@class='btn bg-gradient-primary btn-sm mb-0']")
private WebElement Download3;
@FindBy(xpath="//a[@routerlink=\"/adminpage/partnership\"]")
private WebElement Partnershippage;
@FindBy(xpath="//button[@class='btn bg-gradient-primary btn-sm mb-0']")
private WebElement Download4;
@FindBy(xpath="//a[@routerlink=\"/adminpage/industrial\"]")
private WebElement Industries;
@FindBy(xpath="//a[@routerlink=\"/adminpage/industryAdd\"]")
private WebElement Addinpartner;
@FindBy(xpath="//h2[text()='Successfully Added']")
private WebElement partneraddverify;
@FindBy(xpath="//input[@type='file' and @formcontrolname='img' and @name='dssd' and contains(@class, 'form-control')]")
private WebElement ChooseFile;
@FindBy(xpath="//*[@id=\"imm\"]/div[2]/button")
private WebElement addpartner;
@FindBy(xpath="//a[@routerlink=\"/adminpage/knowledge\"]")
private WebElement Knowledge;
@FindBy(xpath="//a[@routerlink=\"/adminpage/patrons\"]")
private WebElement Patron;
@FindBy(xpath="//a[@routerlink=\"/adminpage/events\"]")
private WebElement Events;
@FindBy(xpath="//a[@routerlink=\"/adminpage/add-events\"]")
private WebElement Addevent;
@FindBy(xpath="//a[@routerlink=\"/adminpage/staffs\"]")
private WebElement Staffs;
@FindBy(xpath="//a[@routerlink=\"/adminpage/admin-user\"]")
private WebElement Adminuser;
@FindBy(xpath="//h1[contains(text(),'ICT Academy of Kerala']")
WebElement logoutverify;
@FindBy(xpath="//a[@data-bs-toggle='collapse' and @href='#ProfileNav' and @role='button' and @aria-expanded='false']")
private WebElement Admin;
@FindBy(xpath="//*[@id=\"ProfileNav\"]/ul/li/a")
private WebElement Logout;

  
public AdminDashboard(WebDriver driver)
{
		this.driver = driver;
		PageFactory.initElements(driver, this);
}

public String Dashboard()
{
	String ActualText=Dashboard.getText();
    return(ActualText);
}
public String Chart()
	{	String ActualText=Chart.getText();
		return(ActualText);
	}
public void whatTo()
	{
	Task.click();
	}
public String EmptySub()
{	
	String ActualText=EmptySub.getText();
	return(ActualText);
}
public void ok()
{
	Ok.click();
	}

public void courses() 
{
	Courses.click();
	view.click();
	driver.navigate().back();
}
public String CoursesList()
{	
	String ActualText=CoursesList.getText();
	return(ActualText);
}
public void csearchhere(String item)
{
	search.click();
	search.sendKeys(item);
	
}
public String searchverify()
{	
	String ActualText=searchverify.getText();
	return(ActualText);
}
public void settings1()
{
	Setting1.click();
}

	public void editcourse(String CourseTitle)
	{
		EditCourse.click();
		NameField.click();
		NameField.clear();
		NameField.sendKeys(CourseTitle);
		Update.click();
	}
	public String editverify()
	{
		String ActualText=editverify.getText();
		return(ActualText);
	}
	

public void testimony()
{
Testimonials.click();
}
public void testimonysearch(String item)	
{
	search.click();
	search.sendKeys(item);
}
public String TestimonyList()
{
	
	String ActualText=TestimonyList.getText();
	return(ActualText);
}
public String SearchverifyTestimony()
{
	String ActualText=SearchverifyTestimony.getText();
	return(ActualText);
}
public void newtestimony(String Name,String Org,String Testimonial)
{

	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    NewTest.click();
	name.sendKeys(Name);
    organisation.sendKeys(Org);
    testi.sendKeys(Testimonial);
    Select dropdown = new Select(CourseSelect);
    dropdown.selectByVisibleText("CERTIFIED SPECIALIST IN FULL STACK DEVELOPMENT using MEAN");
    ChooseFileTestimony.sendKeys("C:\\Users\\ISHU\\Desktop\\New folder\\download.jpg");
    AddTestimonybuttons.click();
    Ok.click();
    
    
}
public String Testimonyaddverify()
{
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
	wait.until(ExpectedConditions.elementToBeClickable((Testimonyaddverify)));
	String ActualText=Testimonyaddverify.getText();
	return(ActualText);
			
}

public void courseregister()
{
CourseReg.click();
}
public String CRU()
{
	String ActualText=CRU.getText();
	return(ActualText);
}

public void downloads1()
{
	Download1.click();
}

public void membership()
{
	AcademicMembership.click();
	
}
public String acad()
{
	String ActualText=acad.getText();
    return(ActualText);
}
public void downloads2()
{
	Download2.click();
}
public void membership2()
{
CorporateMembership.click();
}
public String corp()
{

String ActualText=corp.getText();
return(ActualText);
}

public void downloads3()
{
	Download3.click();
}
public void partnerShip() 
{
	Partnershippage.click();
}
public String partner()
{

String ActualText=partner.getText();
return(ActualText);
}

public void downloads4()
{
	Download4.click();
}

public void industry()
{
	
	Industries.click();
	Addinpartner.click();
	ChooseFile.sendKeys("C:\\Users\\ISHU\\Desktop\\New folder\\download.jpg");
	addpartner.click();
	Ok.click();
}
public String industrypageverify()
{
	String ActualText=industrypageverify.getText();
	return(ActualText);
}
public String partneraddverify()
{
	String ActualText=partneraddverify.getText();
	return(ActualText);
}
public  void knowledge()
{
	Knowledge.click();
}
public String knowledgepageverify()
{
	String ActualText=knowledgepageverify.getText();
	return(ActualText);
	
}
public  void patron()
{
	Patron.click();
}
public String patronpageverify()
{
String ActualText=patronpageverify.getText();
return(ActualText);
}
public  void events()
{
WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
wait.until(ExpectedConditions.elementToBeClickable(Events));
Events.click();
}
public String eventsverify()
{	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
String ActualText=eventsverify.getText();
return(ActualText);
}
public void addevents()
{
	
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
	wait.until(ExpectedConditions.elementToBeClickable((Addevent)));
	Addevent.click();
}
public  void staffs()
{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	Staffs.click();
}
public String staffspageverify()
{
String ActualText=staffspageverify.getText();
return(ActualText);
}

public  void adminuser()
{
	Adminuser.click();
}
public String adminuserverify()
{
String ActualText=adminuserverify.getText();
return(ActualText);
}
public void logoutfunction()
{
Admin.click();
Logout.click();
}
public String logoutverify()
{
	String ActualText=logoutverify.getText();
	return(ActualText);
}

}

