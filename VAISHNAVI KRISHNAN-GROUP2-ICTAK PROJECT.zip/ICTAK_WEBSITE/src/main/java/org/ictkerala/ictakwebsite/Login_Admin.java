package org.ictkerala.ictakwebsite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Login_Admin 
{
WebDriver driver;
@FindBy(xpath="//a[@class='btn btn-sm bg-gradient-info mb-0 me-1 mt-2 mt-md-0' and contains(text(), 'Login')]")
WebElement LoginButton;
@FindBy(xpath="//input[@placeholder='Enter Your Email']")
private WebElement Email;
@FindBy(xpath="//input[@name='password']")
private WebElement Password;
@FindBy(xpath="//button[@type='submit']")
private WebElement SigninButton;	
@FindBy(xpath="//button[@class='swal2-confirm']")
private WebElement Okbutton;
@FindBy(xpath="//h2[@id='swal2-title']")
private WebElement errorMessage;
@FindBy(xpath="//button[@class='swal2-confirm swal2-styled' and text()='OK']")
private WebElement ok;
@FindBy(xpath="//*[@id=\"exampleModalForm\"]")
private WebElement body;
@FindBy(xpath="//small[text()='Email is required']")
private WebElement blankalertmessage;

public  Login_Admin(WebDriver driver)

{
	this.driver=driver;
	PageFactory.initElements(driver, this);
}

public void loginbutton()
{
	LoginButton.click();
}

public void loginCheck(String Email1,String PassWord)
    {
	
	Email.sendKeys(Email1);
    Password.sendKeys(PassWord);
    SigninButton.click();
    }

public String blankalertmessage()
{
String ActualText=blankalertmessage.getText();
return(ActualText);
}

public void invalidcheck(String Email1,String PassWord)
{
	LoginButton.click();
	Email.sendKeys(Email1);
    Password.sendKeys(PassWord);
    SigninButton.click();
    String ActualTitle=errorMessage.getText();
    String ExpectedTitle="Warning!!";
    Assert.assertEquals(ActualTitle, ExpectedTitle);
}


public void clickoutside()
{
	body.click();
}
public void clickok()
{
	 ok.click();
}

}
 
    

	
      


	


