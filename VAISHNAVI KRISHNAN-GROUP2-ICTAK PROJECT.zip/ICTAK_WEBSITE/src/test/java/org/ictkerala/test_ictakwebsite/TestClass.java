package org.ictkerala.test_ictakwebsite;

import org.testng.annotations.Test;

import org.testng.Assert;

import java.time.Duration;

import org.ictkerala.ictakwebsite.AdminDashboard;
import org.ictkerala.ictakwebsite.Login_Admin;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




public class TestClass extends TestBase

{
	


@Test(priority = 0)
public void TC_1()
{
String actualTitle=driver.getTitle();
String expectedTitle="ICT Academy of Kerala";
Assert.assertEquals(actualTitle,expectedTitle); 
System.out.println("Navigated to ICTAK Website");
}
@Test(priority = 1)
public void TC2_1()
{
logad.loginbutton();
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
logad.loginCheck("superadmin","123456");
logad.clickok();

}


@Test(priority=3)
public void TC2_2()
{
logad.loginbutton();
logad.loginCheck("superadmin","12345");
System.out.println("Login Successful");

}

@Test(priority = 3)
public void TC3()
{
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
String ExpectedText="Dashboard";
String ActualText= adash.Dashboard();
Assert.assertEquals(ExpectedText, ActualText);
System.out.println("Successfull Login Navigated to Dashboard");
}
@Test(priority = 4)
public void TC4_1()
{
String ExpectedText = "ICT LIVE STATUS";
String ActualText= adash.Chart();
Assert.assertEquals(ExpectedText, ActualText);
System.out.println("Live Status is Shown");
}
@Test(priority = 5)
public void TC4_2()
{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	adash.whatTo();
	adash.ok();
	String ExpectedText = "Empty Submission";
	String ActualText= adash.EmptySub();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Empty Submission Not Allowed");
}
@Test(priority = 6)
	public void TC4_4() 
	{
	adash.courses();
	String ExpectedText = "Courses List";
	String ActualText=adash.CoursesList();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Navigated to Courses");
	}
@Test(priority = 7)
public void TC_4_5()
{
	adash.csearchhere("software testing");
	String ExpectedText = "SoftwareTesting";
	String ActualText=adash.searchverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Search  is successful");
}
@Test(priority = 8)
public void TC5_3()
{
	adash.editcourse("Certified Specialist in Software Testing");
	String ExpectedText="Certified Specialist in Software Testing";
	String ActualText=adash.editverify();
	Assert.assertNotEquals(ExpectedText,"SoftwareTesting");
	System.out.println("Edit Not Successful");

}

@Test(priority = 9)
public void TC6_1()
{
adash.testimony();
String ExpectedText = "testimony list";
String ActualText=adash.TestimonyList();
Assert.assertEquals(ExpectedText, ActualText);
System.out.println("Succesfull navigation to testimony ");
}
@Test(priority = 10)
public void TC6_2()
{
adash.testimonysearch("Testing");
String ExpectedText = "CERTIFIED SPECIALIST IN SOFTWARE TESTING";
String ActualText=adash.SearchverifyTestimony();
Assert.assertEquals(ExpectedText, ActualText);
System.out.println("Search Successful");
}


@Test(priority = 11)
public void TC6_3()
{
	

 adash.newtestimony("AMAL", "ICTAK", "VERY GOOD COURSE");
 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
 String ActualText=adash.Testimonyaddverify();
 String ExpectedText="Successfully Added";
 Assert.assertEquals(ExpectedText, ActualText);
 System.out.println("New Testimony added");
}

@Test(priority = 12)
public void TC7_1()
{
	adash.courseregister();
	String ExpectedText = "Course Registered Users";
	String ActualText=adash.CRU();
	Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Registered Users is visible");
}
@Test(priority = 13)
public void TC7_2()
{
	adash.downloads1();
	System.out.println("File Downloaded ");
}
@Test(priority = 14)
public void TC8_1()
{
	adash.membership();
	String ExpectedText = "Academic Membership";
	String ActualText=adash.acad();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Succesfully Navigated to Academic Membership page");
}
@Test(priority = 15)
public void TC8_2()
{
	adash.downloads2();
	System.out.println("File Downloaded");
}

@Test(priority = 16)
public void TC9_1()
{
	adash.membership2();
	String ExpectedText = "Corporate Membership";
	String ActualText =adash.corp();
	Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Test Pass");
}

@Test(priority = 17)
public void TC9_2()
{
	adash.downloads3();
	System.out.println("Test Pass");
}

@Test (priority = 18)
public void TC10_1()
{
	adash.partnerShip();
	String ExpectedText = "Partnership Application";
	String ActualText=adash.partner();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Partnership Applications are shown");
}
@Test(priority = 19)
public void TC10_2()
{
	adash.downloads4();
	System.out.println("succesfully Downloaded");
}

@Test(priority = 20)
public void TC11_1()
{
	adash.industry();
	String ExpectedText ="Industrial List";
	String ActualText=adash.industrypageverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Industrial List is shown");
}
@Test(priority = 21)
public void TC11_2()
{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	String ExpectedText1 ="Successfully Added";
	String ActualText1=adash.partneraddverify();
    Assert.assertEquals(ExpectedText1, ActualText1);
    System.out.println("Partner added Successfully");
}

@Test(priority =22 )
public void TC_12_1()
{
	adash.knowledge();
	String ExpectedText = "Knowledge Partner";
	String ActualText=adash.knowledgepageverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Knowledge Partners are shown");

}
@Test(priority=23)
public void TC_12_2()
{
	adash.patron();
	String ExpectedText ="Patrons List";
	String ActualText=adash.patronpageverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Patron Lists are shown");
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

}
@Test(priority=24)
public void TC_12_3()

{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    adash.events();
	String ExpectedText ="Events list";
	String ActualText=adash.eventsverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Events Lists are shown");

}

@Test(priority=25)
public void TC_12_4() 
{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	adash.staffs();
	System.out.println("Staff Lists  are shown");
	
	
	String ExpectedText ="Staff List";
	String ActualText=adash.staffspageverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("Staff Lists  are shown");

}
@Test(priority=26)
public void TC_12_5()
{
	adash.adminuser();
	String ExpectedText ="Admin Users";
	String ActualText=adash.adminuserverify();
    Assert.assertEquals(ExpectedText, ActualText);
	System.out.println("AdminUser Lists are shown");
	
}
@Test(priority=27)
public void TC13()
{
    logobj.logoutfunction();
    String ExpectedText = "ICT Academy of Kerala";
	String ActualText=logobj.logoutverify();
    Assert.assertEquals(ExpectedText, ActualText);
    System.out.println("Succesfully Logged Out");

}





}
