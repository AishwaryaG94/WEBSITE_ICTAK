package org.ictkerala.test_ictakwebsite;

import java.time.Duration;


import org.ictkerala.ictakwebsite.AdminDashboard;
import org.ictkerala.ictakwebsite.Login_Admin;
import org.ictkerala.ictakwebsite.logout;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class TestBase
	{
	WebDriver driver;
	Login_Admin logad;
	AdminDashboard adash;
	logout logobj;
	
	@BeforeClass
	public void testConfig()
	{
	  
	    driver =new ChromeDriver();
	    logad=new Login_Admin(driver);
	    adash=new AdminDashboard(driver);
	    logobj=new logout(driver);
		driver.get("http://64.227.132.109/LandingPage");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
    @AfterClass
    
	public void TearDown()
	{
	System.out.println("All Test Cases Executed");
	}  
	}



