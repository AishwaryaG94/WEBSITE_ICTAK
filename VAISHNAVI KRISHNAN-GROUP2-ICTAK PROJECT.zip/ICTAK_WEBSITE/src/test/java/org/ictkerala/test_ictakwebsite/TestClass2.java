package org.ictkerala.test_ictakwebsite;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass2 extends TestBase
{



@Test(priority=0)
public void TC13()
{

   logad.loginbutton();
    logad.loginCheck("superadmin","12345");
    logobj.logoutfunction();
    String ExpectedText = "ICT Academy of Kerala";
	String ActualText=logobj.logoutverify();
    Assert.assertEquals(ExpectedText, ActualText);

}



}
