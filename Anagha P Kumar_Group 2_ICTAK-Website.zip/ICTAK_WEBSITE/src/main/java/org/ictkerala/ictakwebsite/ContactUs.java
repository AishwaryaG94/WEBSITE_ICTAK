package org.ictkerala.ictakwebsite;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ContactUs {
	WebDriver driver;

	@FindBy(xpath="//a[@id='dropdownMenuPages'and@routerlink='/LandingPage/contactus']")
	private WebElement contactUs;
	@FindBy(xpath="//input[@name='name'and @placeholder='Full Name']")
	private WebElement mynameis;
	@FindBy(xpath="//input[@type='email']")
	private WebElement myemailidis;
	@FindBy(xpath="//input[@name='coursename' and @type='text']")
	private WebElement imlookingfor;
	@FindBy(xpath="//input[@name='subject' and @id='message']")
	private WebElement yourmessage;
	@FindBy(xpath="//button[@class='btn btn-round bg-gradient-info mb-0' and @type='submit']")
	private WebElement sendmessage;
	@FindBy(xpath="//img[@alt='main_logo' and @class='mb-3 footer-logo']")
	private WebElement logo;
	
	public ContactUs(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setcts()
	{
		WebElement YourConnectiontoICTAK=driver.findElement(By.xpath("//a[@id='dropdownMenuPages'and@routerlink='/LandingPage/contactus']"));
		String actualres=YourConnectiontoICTAK.getText();
		String excepres=actualres;
		Assert.assertEquals(actualres, excepres);
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",contactUs);
	}
	
	public void nam(String Name)
	{
		mynameis.sendKeys(Name);	
	}
	public void mail(String mailid)
	{
		myemailidis.sendKeys(mailid);	
	}
	public void lkfr(String msg)
	{
		imlookingfor.sendKeys(msg);	
	}
	public void yurmsg(String ymsg)
	{
		yourmessage.sendKeys(ymsg);
	} 
	public String alert()
	{
		Alert alert = driver.switchTo().alert();
		String alertMsg = driver.switchTo().alert().getText();
		alert.accept();
		return(alertMsg);
	}
	public  void sndmsg()
	{
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	Actions actions = new Actions(driver);
	actions.moveToElement(sendmessage).click().perform();
	driver.switchTo().alert().accept();
	
	}
	
	public void log()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Actions actions = new Actions(driver);
		actions.moveToElement(logo).click().perform();
		
	}

}