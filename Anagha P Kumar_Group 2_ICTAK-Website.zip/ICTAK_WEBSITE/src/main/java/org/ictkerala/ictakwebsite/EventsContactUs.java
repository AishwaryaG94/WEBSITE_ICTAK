package org.ictkerala.ictakwebsite;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;



 	public class EventsContactUs{
	WebDriver driver;
	@FindBy(xpath="//*[@class='nav-item dropdown dropdown-hover mx-2'][5]")
	private WebElement Events;
	@FindBy(xpath="//*[@id=\"navigation\"]/ul/li[5]/ul/div[1]/ul/li[1]/a/span")
	private WebElement ICSET;
	@FindBy(xpath="//button[@class='btn bg-gradient-success w-auto me-2 mt-4 ng-star-inserted']")
	private WebElement ApplyNow;
	@FindBy(xpath="//input[@name='name']")
	private WebElement Name;
	@FindBy(xpath="//input[@type='email']")
	private WebElement Email;
	@FindBy(xpath="//input[@name='phoneno']")
	private WebElement Number;
	@FindBy(xpath="//button[@class='btn bg-gradient-primary w-100 mt-4 mb-0']")
	private WebElement Register;
	@FindBy(xpath="//img[@alt='main_logo']")
	private WebElement ICTLogo;
	@FindBy (xpath="//button[@type='button'][@class='btn bg-gradient-success w-auto me-2 mt-4']")
	private WebElement reapply;

	@FindBy(xpath="//*[@id=\"navigation\"]/ul/li[5]/ul/div[1]/ul/li[2]/a/h6")
	private WebElement Techathlon;
	@FindBy(xpath="//button[@type='button' and  @class='btn bg-gradient-success w-auto me-2 mt-4 ng-star-inserted']")
	private WebElement ApplyNow1;
	@FindBy(xpath="//input[@type='text' and @class='form-control is-valid ng-untouched ng-pristine ng-invalid']")
	private WebElement Name1;
	@FindBy(xpath="//input[@type='email' and @class='form-control ng-untouched ng-pristine ng-invalid']")
	private WebElement Email1;
	@FindBy(xpath="//input[@placeholder='Number' and @class='form-control ng-untouched ng-pristine ng-invalid']")
	private WebElement Number1;
	@FindBy(xpath="//button[@type='submit' and @class='btn bg-gradient-primary w-100 mt-4 mb-0']")
	private WebElement Register1;
	@FindBy(xpath="//img[@class='mb-3 footer-logo']")
	private WebElement ICTLogo1;
	@FindBy (xpath="//button[@type='button'][@class='btn bg-gradient-success w-auto me-2 mt-4']")
	private WebElement reapply1;

	public EventsContactUs(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
	public void evn()
	{
		Events.click();
		String actualres1=Events.getText();
		String expectres1=actualres1;
		Assert.assertEquals(actualres1, expectres1);
		
	}	

	public void  icset()
	{
		ICSET.click();
		String actualres1=	ICSET.getText();
		String expectres1=actualres1;
		Assert.assertEquals(actualres1, expectres1);
	}
	
	public void  aply()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",ApplyNow);
	}
	public void Reapply()
	{
		reapply.click();
	}
	
	public void nme(String name)
	  {
		Name.clear();
		Name.sendKeys(name);
	  }
	
	public void eml(String email)
	  {
		Email.clear();
		Email.sendKeys(email);
	  }
	
	public void phno(String num)
	  {
		Number.clear();
		Number.sendKeys(num);
	  }
	public void reg()
	{
		Register.click();
	}
	public String alert()
	{
		Alert alert = driver.switchTo().alert();
		String alertMsg = driver.switchTo().alert().getText();
		alert.accept();
		return(alertMsg);
	}
	public void log()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		Actions actions = new Actions(driver);
		actions.moveToElement(ICTLogo).click().perform();
	
	}	
	
	public void techa()
	 {
		Techathlon.click();
		String actualres=Techathlon.getText();
		String exceptres=actualres;
		Assert.assertEquals(actualres, exceptres);
	 }
	public void  aply1()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",ApplyNow1);
	}
	public void Reapply1()
	{
		reapply.click();
	}

	public void nme1(String name)
	  {
		Name1.sendKeys(name);
	  }
	
	public void eml1(String email)
	  {
		Email1.sendKeys(email);
	  }
	
	public void phno1(String num)
	  {
		Number1.sendKeys(num);
	  }
	public void reg1()
	{
		Register1.click();
	  }
	public void log1()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		Actions actions = new Actions(driver);
		actions.moveToElement(ICTLogo1).click().perform();
	}
 }
 
 	