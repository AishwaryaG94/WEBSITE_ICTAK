package org.ictkerala.test_ictakwebsite;

import java.time.Duration;

import org.ictkerala.ictakwebsite.ContactUs;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClassCus extends TestBase_ICTAK{
	ContactUs cntobj;
	
	@Test(priority=1)
	public void TC_C16()
	{
		cntobj = new ContactUs(driver);
		cntobj.setcts();
		System.out.println("Navigated to ContactUs Page");
	 }    
	

	@Test(priority=2)
	public void TC_C171() throws InterruptedException
	{
		cntobj = new ContactUs(driver);
        cntobj.nam("Anagha");
        cntobj.mail("anagha@gmail.com");
        cntobj.lkfr("Software Tester");
        cntobj.yurmsg("Hi");
        cntobj.sndmsg();
        System.out.println("Send Message is successful");
        String expecres="Send Message is successful";
        String actualres=expecres;
        Assert.assertEquals(expecres, expecres);
        driver.navigate().refresh();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        
	}
	@Test(priority=3)
	public void TC_C172() throws InterruptedException
	{
		cntobj = new ContactUs(driver);
        cntobj.nam("");
        cntobj.mail("anagha@gmail.com");
        cntobj.lkfr("Software Tester");
        cntobj.yurmsg("Hi");
        String expecres="Send Message is successful";
        String actralres="Send Message is Unsuccessful";
        Assert.assertNotEquals(actralres, expecres);
        System.out.println("Send Message button is inactive due to name field is blank");   
        driver.navigate().refresh();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
       
	}
	@Test(priority=4)
	public void TC_C173() throws InterruptedException
	{
		cntobj = new ContactUs(driver);
        cntobj.nam("Anagha");
        cntobj.mail("");
        cntobj.lkfr("Software Tester");
        cntobj.yurmsg("Hi");
        String expecres="Send Message is successful";
        String actralres="Send Message is Unsuccessful";
        Assert.assertNotEquals(actralres, expecres);
        System.out.println("Send Message button is inactive due to email field is blank");
        driver.navigate().refresh();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
       
     }
	@Test(priority=5)
	public void TC_C174() throws  InterruptedException
	{
		cntobj = new ContactUs(driver);
		Thread.sleep(3000);
        cntobj.nam("Anagha");
        cntobj.mail("anagha@gmail.com");
        cntobj.lkfr("");
        cntobj.yurmsg("");
        String expecres="Send Message is successful";
        String actralres="Send Message is Unsuccessful";
        Assert.assertNotEquals(actralres, expecres);
        System.out.println("Send Message button is inactive due to I'm Looking for field and Your Message field is blank");
        driver.navigate().refresh();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
       
     }
	@Test(priority=6)
	public void TC_C175() throws InterruptedException
	{
		cntobj = new ContactUs(driver);
        cntobj.nam("");
        cntobj.mail("");
        cntobj.lkfr("");
        cntobj.yurmsg("");
        String expecres="Send Message is successful";
        String actralres="Send Message is Unsuccessful";
        Assert.assertNotEquals(actralres, expecres);
        System.out.println("Send Message button is inactive due to all fields are blank");
        driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        
      }
	@Test(priority=7)
	public void TC_19()
	{
		cntobj= new ContactUs(driver);
		cntobj.setcts();
		cntobj.log();
		System.out.println("Back to home page");
	}
}