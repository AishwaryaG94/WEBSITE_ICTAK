package org.ictkerala.test_ictakwebsite;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;



public class TestBase_ICTAK {
	
	WebDriver driver;
	String expevnt = "Events";
	String expcnt = "ContactUs";

	
	@BeforeClass
	public void testConfig()
	{
	driver=new ChromeDriver();
	driver.get("http://64.227.132.109/LandingPage");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@AfterClass
	 public void end()  {
		   
		   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	  }

}

