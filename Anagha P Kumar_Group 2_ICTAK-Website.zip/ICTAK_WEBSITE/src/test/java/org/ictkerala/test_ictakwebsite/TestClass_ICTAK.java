package org.ictkerala.test_ictakwebsite;

import java.time.Duration;

import org.ictkerala.ictakwebsite.EventsContactUs;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass_ICTAK extends TestBase_ICTAK{
	EventsContactUs evnobj;
	
	@Test(priority=1)
	public void TC_1() throws InterruptedException
	{
		evnobj = new EventsContactUs(driver);
		evnobj.evn();
        System.out.println("Navigated to Events");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
 
	}
	@Test(priority=2)
		public void TC_2() throws InterruptedException
		{
			evnobj = new EventsContactUs(driver);
	        evnobj.evn();
	        System.out.println("Events dropdown is loaded");
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	        
	    }
	@Test(priority=2)
	public void TC_3() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.icset();
			System.out.println("Navigated to the ICSET Page");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
	}
	@Test(priority=3)
	public void TC_I71() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.aply();
			evnobj.nme("ANAGHA");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("1234567890");
			evnobj.reg();
	    	String ExpectText="Registration Successfull";
	    	String alertMsg=evnobj.alert();
	    	Assert.assertEquals(ExpectText, alertMsg);
	    	System.out.println(alertMsg);
	    	System.out.println("Registration Successfull");
	    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
     }
	@Test(priority=4)
	public void TC_I72() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("anagha");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("1234567890");
			evnobj.reg();
			String ExpectText1="Registration Successfull";
	    	String alertMsg1=evnobj.alert();
	    	Assert.assertEquals(ExpectText1, alertMsg1);
	    	System.out.println(alertMsg1);
			System.out.println("Registration Successfull");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		    
	}
	@Test(priority=5)
	public void TC_I73() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("1234567890");
			String expecres="Registration successfull";
	    	String actualres="Registration Unsuccessfull";
	    	Assert.assertNotSame(actualres, expecres);
	    	System.out.println("Registration unsuccessfull,Register Button is inactive due to Name field is blank");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			
	}
	@Test(priority=6)
	public void TC_I74() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("Anagha");
			evnobj.eml("");
			evnobj.phno("1234567890");
			String expecres1="Registration successfull";
	    	String actualres1="Registration Unsuccessfull";
	    	Assert.assertNotSame(expecres1, actualres1);
			System.out.println("Registration Unsuccessfull,Register Button is inactive due to email field is blank");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.navigate().refresh();
		    
	}
	@Test(priority=7)
	public void TC_I75() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("Anagha");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("");
			String expecres2="Registration successfull";
	    	String actualres2="Registration Unsuccessfull";
	    	Assert.assertNotEquals(expecres2, actualres2);
			System.out.println("Register Button is inactive due to Number field is blank");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		    
	}
	@Test(priority=8)
	public void TC_8() throws InterruptedException
	{
			evnobj= new EventsContactUs(driver);
			evnobj.evn();
			evnobj.log();
			String expectText="ICT Academy of Kerala";
			String actualText="ICT Academy of Kerala";
			Assert.assertEquals(expectText, actualText);
			System.out.println("Back to Home page");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.navigate().refresh();
		   
	}
	@Test(priority=9)
	public void TC_9() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.evn();
			evnobj.techa();
			System.out.println("Navigated to the Techathlon Page");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			
	}
	@Test(priority=10)
	public void TC_T121() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.aply1();
			evnobj.nme1("ANAGHA");
			evnobj.eml1("anagha@gmail.com");
			evnobj.phno1("1234567890");
			evnobj.reg1();
			String ExpectText="Registration Successfull";
	    	String alertMsg=evnobj.alert();
	    	Assert.assertEquals(ExpectText, alertMsg);
			System.out.println("Registration Successfull");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
     } 
	@Test(priority=11)
	public void TC_T122() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply1();
			evnobj.nme("anagha");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("1234567890");
			evnobj.reg();
			String ExpectText="Registration Successfull";
	    	String alertMsg=evnobj.alert();
	    	Assert.assertEquals(ExpectText, alertMsg);
			System.out.println("Registration Successfull");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@Test(priority=12)
	public void TC_T123() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("1234567890");
			String expecres1="Registration successfull";
	    	String actualres1="Registration Unsuccessfull";
	    	Assert.assertNotSame(expecres1, actualres1);
			System.out.println("Registration Unsuccessfull,Register Button is inactive due to Name field is blank");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.navigate().refresh();
	}
	@Test(priority=13)
	public void TC_T124() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("Anagha");
			evnobj.eml("");
			evnobj.phno("1234567890");
			String expecres1="Registration successfull";
	    	String actualres1="Registration Unsuccessfull";
	    	Assert.assertNotSame(expecres1, actualres1);
			System.out.println("Registration Unsuccessfull,Register Button is inactive due to email field is blank");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@Test(priority=14)
	public void TC_T125() throws InterruptedException
	{
			evnobj = new EventsContactUs(driver);
			evnobj.Reapply();
			evnobj.nme("Anagha");
			evnobj.eml("anagha@gmail.com");
			evnobj.phno("");
			String expecres1="Registration successfull";
	    	String actualres1="Registration Unsuccessfull";
	    	Assert.assertNotSame(expecres1, actualres1);
			System.out.println("Registration Unsuccessfull,Register Button is inactive due to Number field is blank");
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@Test(priority=15)
	public void TC_15() throws InterruptedException
	{
			evnobj= new EventsContactUs(driver);
			evnobj.evn();
			evnobj.log1();
			System.out.println("Back to Home page");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
}

	